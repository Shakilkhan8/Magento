{
    # App information
    'name': "Magento 2 Extended Bundle Products Order EPT",
    'version': '16.0.1.0.1',
    'category': 'Sales',
    'license': 'OPL-1',
    'summary': 'Odoo Magento 2 Extended EPT module helps you import the bundle product order from'
               'magento 2.x website into the odoo',
    # Author
    'author': 'Emipro Technologies Pvt. Ltd.',
    'website': 'http://www.emiprotechnologies.com/',
    'maintainer': 'Emipro Technologies Pvt. Ltd.',

    # Dependencies
    'depends': ['odoo_magento2_ept', 'mrp'],
    # Views
    'data': [

    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
